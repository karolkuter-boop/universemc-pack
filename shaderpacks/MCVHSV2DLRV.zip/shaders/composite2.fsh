#include "lib/version.glsl"

varying vec2 texcoord;

#include "lib/uniforms.glsl"
#include "lib/common.glsl"

const vec2 offsets[25] = vec2[25]
(
    vec2(-2, 2), vec2(-1, 2), vec2(0, 2), vec2(1, 2), vec2(2, 2),
    vec2(-2, 1), vec2(-1, 1), vec2(0, 1), vec2(1, 1), vec2(2, 1),
    vec2(-2, 0), vec2(-1, 0), vec2(0, 0), vec2(1, 0), vec2(2, 0),
    vec2(-2, -1), vec2(-1, -1), vec2(0, -1), vec2(1, -1), vec2(2, -1),
    vec2(-2, -2), vec2(-1, -2), vec2(0, -2), vec2(1, -2), vec2(2, -2)
);

const float weights[25] = float[25]
(
    1, 4,  7,  4,  1,
    4, 16, 26, 16, 4,
    7, 26, 41, 26, 7,
    4, 16, 26, 16, 4,
    1, 4,  7,  4,  1
);

void main()
{
    vec4 colour = texture2D(colortex0, texcoord);

    vec3 blurred = vec3(0);

    vec2 px = 1.0 / (vec2(viewWidth, viewHeight) / exp2(LUMA_QUALITY));

    for(int i = 0; i < 25; i++)
    {
        blurred += texture2D(colortex0, texcoord + offsets[i] * px).rgb * weights[i];
    }

    colour.rgb = mix(colour.rgb, blurred * 0.003663, -1.0 * SHARPNESS);

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = colour;
}