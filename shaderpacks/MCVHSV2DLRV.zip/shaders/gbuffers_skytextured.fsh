#include "lib/version.glsl"

varying vec2 texcoord;

#include "lib/uniforms.glsl"
#include "lib/common.glsl"

void main()
{
    /* DRAWBUFFERS:0 */
    // Card #59: no sky textures (sun/moon/clouds/stars) drawn over the Backrooms void.
    discard;
}