#include "version.glsl"

#if defined(VERTEX)

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolour;

attribute vec4 at_tangent;
attribute vec3 mc_Entity;

varying mat3 tbn;
varying float block_id;

#include "uniforms.glsl"
#include "common.glsl"

void main()
{
    gl_Position = ftransform();

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolour = gl_Color;

    vec3 normal = normalize(gl_Normal);
    vec3 tangent = normalize(at_tangent.xyz);
    vec3 binormal = normalize(cross(tangent, normal));

    tbn = mat3
    (
        tangent.x, binormal.x, normal.x,
        tangent.y, binormal.y, normal.y,
        tangent.z, binormal.z, normal.z
    );

    block_id = mc_Entity.x;
}

#elif defined (FRAGMENT)

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolour;

varying mat3 tbn;
varying float block_id;

#include "uniforms.glsl"
#include "common.glsl"

void main ()
{
    vec4 colour = texture2D(gtexture, texcoord);
    if(colour.a < 0.1) discard;
    colour.rgb = sRGBToLinear(colour.rgb);

    vec3 screen_point = gl_FragCoord.xyz / vec3(viewWidth, viewHeight, 1.0);
    vec3 view_point = TransformScreenToViewPoint(screen_point);
    vec3 world_point = TransformScreenToWorldPoint(screen_point);

    vec3 geo_normal = normalize(vec3(tbn[0][2], tbn[1][2], tbn[2][2]));

    vec3 pix_normal = vec3(texture2D(normals, texcoord).xy * 2.0 - 1.0, 0.0);
    pix_normal.z = sqrt(1.0 - dot(pix_normal.xy, pix_normal.xy));
    pix_normal = normalize(pix_normal * tbn);

    vec4 spec = texture2D(specular, texcoord);
    spec.x = pow(1.0 - spec.x, 2.0);
    spec.a = spec.a > 0.997 ? 0.0 : spec.a;

    colour.rgb = colour.rgb * sRGBToLinear(glcolour.rgb) * sRGBToLinear(glcolour.aaa);
    vec3 base_colour = colour.rgb;

    vec3 sun_direction = LightPosToWorldDir(sunPosition);
    float sky_light = pow(sun_direction.y * 0.5 + 0.5, 3.0);
    sky_light *= (1.0 - rainStrength) * 0.1 + 0.9;

    colour.rgb = base_colour * pow(lmcoord.y, 3.0) * sky_light + base_colour * (pow(lmcoord.x, 5.0) * 3.0 * blocklight_colour + spec.a * 3.0);

    float player_light_mask = 1.0;

    #ifdef HELD_ITEM_SPOTLIGHT
        vec3 light_dir_to_frag = normalize(world_point);
        vec3 light_direction = normalize(vec3(-gbufferModelView[0][2], -gbufferModelView[1][2], -gbufferModelView[2][2]));

        float innerCutoff = cos(radians(5.0));
        float outerCutoff = cos(radians(40.0));

        float theta = dot(light_dir_to_frag, light_direction);
        float epsilon = innerCutoff - outerCutoff;
        player_light_mask = clamp((theta - outerCutoff) / epsilon, 0.0, 1.0);
        player_light_mask *= max(0.0, dot(pix_normal, -light_direction));
    #endif

    float held_item_light = heldBlockLightValue * HELD_ITEM_BRIGHTNESS;
    float player_light = max(0.0, (held_item_light - length(world_point)) / held_item_light);

    colour.rgb += player_light * player_light * player_light * player_light_mask * base_colour * 3.0 * blocklight_colour;

    colour.rgb += base_colour * sRGBToLinear(entityColor.rgb) * entityColor.a;

    float max_fog_dist = far;
    #ifdef DISTANT_HORIZONS
        max_fog_dist = float(dhRenderDistance);
    #endif
    max_fog_dist = (isEyeInWater == 2 ? 3.0 : isEyeInWater == 1 ? 10.0 : max_fog_dist);

    float fog = length(world_point) / max_fog_dist;
    vec3 fog_col = mix(vec3(0.0), fogColor, float(eyeBrightnessSmooth.y) / 240.0);
    colour.rgb = mix(colour.rgb, sRGBToLinear(fog_col), smoothstep(0.0, 1.0, min(1.0, fog)));

    /* DRAWBUFFERS:0123 */
    gl_FragData[0] = colour;
    gl_FragData[1] = vec4(geo_normal, 1.0);
    gl_FragData[2] = vec4(pix_normal, 1.0);
    gl_FragData[3] = spec;
}

#endif