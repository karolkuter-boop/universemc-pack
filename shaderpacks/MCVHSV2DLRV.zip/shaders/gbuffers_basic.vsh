#define VERTEX
#include "lib/gbuffers_lit.glsl"