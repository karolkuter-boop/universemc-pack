UniverseMC — instancja samo-aktualizująca się
=============================================

Co to:
  Cienka instancja Prism Launchera (~100 KB) — ładuje wszystkie mody automatycznie
  z repo https://github.com/karolkuter-boop/universemc-pack przy KAŻDYM uruchomieniu.
  Nowy mod/wersja po commitcie do repo = pojawia się u Ciebie po prostu odpalając grę.

Instalacja:
  1. Rozpakuj cały folder "UniverseMC-AutoUpdate" do:
       %APPDATA%\PrismLauncher\instances\
     (Czyli ścieżka: C:\Users\<TY>\AppData\Roaming\PrismLauncher\instances\UniverseMC-AutoUpdate\)
  2. Otwórz Prism Launcher — zobaczysz instancję "UniverseMC (auto-update)".
  3. Kliknij "Play". Bootstrap pobierze mody (~jednorazowo ~150 MB) i odpali grę.
  4. Następne odpalenia: bootstrap sprawdza index — pobiera tylko zmiany.

Co dostajesz:
  • Minecraft 26.1.2 + NeoForge 26.1.2.71
  • UniverseMC (mod podstawowy)
  • Sodium + Iris (wydajność + shadery)
  • WorldEdit (po stronie serwera)
  • Complementary Reimagined + Unbound (shadery do wyboru)

LAB:
  Domyślny event "kasetka" w Ferajna LAB to BACKROOMS — Poziom 0. Wpadasz do tego
  liminalnego korytarza przez portal "Strefa Ferajny" w hubie.

Wymagania systemowe:
  • RAM: 4-8 GB przydzielone (już ustawione w instance.cfg)
  • Java: Prism sam zainstaluje Javę 25 z Microsoft Build OpenJDK.
