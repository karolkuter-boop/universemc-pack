UniverseMC — auto-updating Prism Launcher instance
===================================================

CO TO JEST
  Lekka instancja Prism Launcher (Minecraft 26.1.2 + NeoForge 26.1.2.73),
  ktora przy KAZDYM uruchomieniu sama pobiera najnowsza wersje paczki przez
  packwiz z:
  https://raw.githubusercontent.com/karolkuter-boop/universemc-pack/main/pack.toml

  Czyli: gdy wyjdzie nowy update moda UniverseMC, wystarczy odpalic instancje
  i mody zaktualizuja sie automatycznie. Nic nie trzeba pobierac recznie.

JAK ZAINSTALOWAC (Prism Launcher)
  1. Otworz Prism Launcher.
  2. Add Instance  ->  zakladka "Import"  ->  wskaz ten plik .zip
     (albo po prostu przeciagnij .zip na okno Prisma).
     WAZNE: uzyj zakladki "Import", NIE "Custom" — inaczej Prism wytnie
     komende auto-update (pre-launch).
  3. Uruchom instancje "UniverseMC". Pierwszy start pobierze mody (chwile to
     potrwa), kolejne starty tylko doinstaluja zmiany.

UWAGI
  - To jest paczka pod PRISM LAUNCHER. NIE otwieraj jej w Modrinth App.
  - Mody sa zarzadzane automatycznie przez packwiz — nie dodawaj/usuwaj ich
    recznie w folderze mods (zostana nadpisane przy nastepnym starcie).
  - WorldEdit jest po stronie serwera, wiec celowo nie pobiera sie na kliencie.
