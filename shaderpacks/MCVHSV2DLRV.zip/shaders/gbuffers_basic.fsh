#define FRAGMENT
#include "lib/gbuffers_lit.glsl"