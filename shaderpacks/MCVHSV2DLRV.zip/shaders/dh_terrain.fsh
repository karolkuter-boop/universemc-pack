#include "lib/version.glsl"

#include "lib/uniforms.glsl"
#include "lib/common.glsl"

varying vec2 lmcoord;
varying vec4 glcolour;

void main()
{
    vec4 output = glcolour;

    if(output.a < 0.1)
    {
        discard;
    }

    output.rgb = sRGBToLinear(output.rgb);

    vec3 screen_point = gl_FragCoord.xyz / vec3(viewWidth, viewHeight, 1.0);
    vec3 view_point = TransformScreenToViewPoint(screen_point);
    vec3 world_point = TransformScreenToWorldPoint(screen_point) * float(dhRenderDistance);

    vec2 screen_coord = screen_point.xy;
    float depth = texture2D(depthtex0, screen_coord).x;
    float linear_depth = LinearizeDepth(depth, near, far * 4.0);
    float dh_depth = gl_FragCoord.z;
    float linear_dh_depth = LinearizeDepth(dh_depth, dhNearPlane, dhFarPlane);

    if(linear_depth < linear_dh_depth && depth < 1.0)
    {
        discard;
    }

    vec3 sun_direction = LightPosToWorldDir(sunPosition);
    float sky_light = pow(sun_direction.y * 0.5 + 0.5, 3.0);
    sky_light *= (1.0 - rainStrength) * 0.1 + 0.9;
    output.rgb *= sky_light;

    float max_fog_dist = dhFarPlane;
    max_fog_dist = (isEyeInWater == 2 ? 3.0 : isEyeInWater == 1 ? 10.0 : max_fog_dist);

    float fog = length(world_point) / max_fog_dist;
    vec3 fog_col = mix(vec3(0.0), fogColor, float(eyeBrightnessSmooth.y) / 240.0);
    output.rgb = mix(output.rgb, sRGBToLinear(fog_col), smoothstep(0.0, 1.0, min(1.0, fog)));

    float dh_blend = smoothstep(0.0, 1.0, length(world_point));

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(output.rgb, mix(0.0, output.a, dh_blend));
}