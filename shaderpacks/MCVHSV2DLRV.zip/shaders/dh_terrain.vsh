#include "lib/version.glsl"

#include "lib/uniforms.glsl"
#include "lib/common.glsl"

varying vec2 lmcoord;
varying vec4 glcolour;

void main()
{
    gl_Position = ftransform();

    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolour = gl_Color;
}