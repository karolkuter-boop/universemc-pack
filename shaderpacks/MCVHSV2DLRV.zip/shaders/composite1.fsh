#include "lib/version.glsl"

varying vec2 texcoord;

#include "lib/uniforms.glsl"
#include "lib/common.glsl"

vec3 yuv2rgb(vec3 yuv)
{
    float y = yuv.x;
    float u = yuv.y;
    float v = yuv.z;
    
    return vec3
    (
        y + 1.0 / 0.877 * v,
        y - 0.39393 * u - 0.58081 * v,
        y + 1.0 / 0.493 * u
    );
}

void main()
{
    vec4 colour = texture2D(colortex0, texcoord);

    float luma = texture2DLod(colortex0, texcoord, LUMA_QUALITY).r;
    vec2 chroma = texture2DLod(colortex0, texcoord, CHROMA_QUALITY).gb;
    colour.rgb = yuv2rgb(vec3(luma, chroma));
    colour.rgb = clamp(LinearToSRGB(colour.rgb), vec3(0.0), vec3(1.0));

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = colour;
}