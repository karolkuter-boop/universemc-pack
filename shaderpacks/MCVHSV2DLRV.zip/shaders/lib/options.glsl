#ifndef OPTIONS
#define OPTIONS

#define LENS_DISTORTION

#define FAST_LINEAR_SRGB

#define ASPECT_RATIO

#define COLOUR_DEPTH 256.0 //[8.0 16.0 32.0 64.0 128.0 256.0 512.0 1024.0]

#define LUMA_QUALITY 2.0 //[0.0 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0]
#define CHROMA_QUALITY 4.0 //[0.0 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0]

#define LUMA_NOISE 0.05 //[0.0 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.9 0.9 1.0]
#define CHROMA_NOISE 0.2 //[0.0 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.9 0.9 1.0]

#define INTERLACING
#define INTERLACE_FRAMERATE 24.0 //[24.0 30.0 60.0]

#define SHARPNESS 1.0 //[0.0 0.5 1.0 1.5 2.0]

#define HELD_ITEM_BRIGHTNESS 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define HELD_ITEM_SPOTLIGHT

#endif