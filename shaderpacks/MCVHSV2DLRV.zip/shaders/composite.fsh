#include "lib/version.glsl"

varying vec2 texcoord;

#include "lib/uniforms.glsl"
#include "lib/common.glsl"

vec3 rgb2yuv(vec3 rgb)
{
    float y = 0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b;
    return vec3(y, 0.493 * (rgb.b - y), 0.877 * (rgb.r - y));
}

void main()
{
    // Card #59: psyche bridge -- darknessFactor+blindness rise as psyche drops (BackroomsEvent applies
    // DARKNESS<=30, BLINDNESS<=15). psy in 0..1: 0 = full psyche (calm baseline), 1 = low psyche (amped VHS).
    float psy = clamp(darknessFactor + blindness, 0.0, 1.0);

    vec2 final_texcoord = texcoord;
    #ifdef LENS_DISTORTION
        vec2 distorted_texcoord = (texcoord * 2.0 - 1.0);
        distorted_texcoord *= 1.0 + dot(distorted_texcoord, distorted_texcoord) * (0.1 + psy * 0.15);
        distorted_texcoord = (distorted_texcoord * 0.85) * 0.5 + 0.5;

        final_texcoord = distorted_texcoord;
    #endif

    vec4 colour = texture2D(colortex0, final_texcoord);

    colour.rgb = floor(colour.rgb * COLOUR_DEPTH) / COLOUR_DEPTH;

    colour.rgb = rgb2yuv(colour.rgb);
    
    vec2 noise_coord = gl_FragCoord.xy / 256.0;
    vec4 noise = texture2D(noisetex, noise_coord);
    noise = fract(noise + fract(frameTimeCounter * 5.0)) * 2.0 - 1.0;

    colour.r += noise.x * LUMA_NOISE * 0.5 * (1.0 + psy * 3.0);
    colour.gb += noise.yz * CHROMA_NOISE * 0.5 * (1.0 + psy * 3.0);

    #ifdef ASPECT_RATIO
        colour.rgb *= abs(texcoord.x * 2.0 - 1.0) < 0.75 ? 1.0 : 0.0;
    #endif

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = colour;
}