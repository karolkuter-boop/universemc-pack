#include "lib/version.glsl"

varying vec2 texcoord;

#include "lib/uniforms.glsl"
#include "lib/common.glsl"

void main()
{
    vec4 colour = texture2D(colortex0, texcoord);
    vec4 prev_frame = texture2D(colortex4, texcoord);

    #ifdef INTERLACING
        float interlace_mask = fract(gl_FragCoord.y * 0.25) > 0.5 ? 1.0 : 0.0;
        interlace_mask = fract(frameTimeCounter * INTERLACE_FRAMERATE) > 0.5 ? 1.0 - interlace_mask : interlace_mask;

        colour = mix(colour, prev_frame, interlace_mask);
        prev_frame = colour;
    #endif

    /* DRAWBUFFERS:04 */
    gl_FragData[0] = colour;
    gl_FragData[1] = prev_frame;
}